# Time-Date-Tracker 
Thank you TheMrEvil for helping organize the Library so the Context, Input and Output Hooks could look clearner.
 Hello,
 This script will apply a time and day tracker. The clock works from 00:00-24:00 and will display whether it is morning, afternoon, evening or night. time of days as follows
Morning: 06:00-11:59
Afternoon: 12:00-16:59
Evening: 17:00-19:59
Night: 20:00-05:59

I have also added in One Story Card/Configuration Cards.  
Time and Day Card
** Time And Day:** Here it will display your current time and day in game. 
-You can also adjust the clock to another time and it will update your current time. the Ai will then display the amount of time that passed.
-You can also turn off all time displayed if you prefer it to not be displayed in game, The card will continue to update your time and Day.
-Shows how many minutes pass per action and can be adjusted from 1 minute to 60 minutes.
-In the Note Section I have provide a command you use in the do action that will advance you to the next day when you sleep at night.
